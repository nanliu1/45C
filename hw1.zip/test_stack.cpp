 #include "stack.h"
 #include <iostream>
using namespace std;

void pushAll(Stack & stk, string str)
{
        for (int i = 0; i < str.size(); ++i)
                stk.push(str[i]);
}

void popAll(Stack & stk, string str)
{
        for (int i = 0; i < str.size(); ++i)
		cout << stk.pop();
	cout << "\n";
}

int main()
{
        string in;
        Stack stk;

        while ( getline( cin, in ) )
        {  
		pushAll( stk, in );
                popAll( stk, in );
        }
        return 0;

}
