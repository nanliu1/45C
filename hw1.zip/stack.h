 #define STACK_CAPACITY 1000
 #include <string>
 #include <iostream>
using namespace std;

class Stack
{
	char stk[STACK_CAPACITY];
	int tp;
	void error( string s)
	{
		cerr << "Error." << s << endl;
	}

public:
	Stack()
		:tp(0)
	{
	}
	void push( char c )
	{
		if (isFull())
		{
			error("push on a full stack");
			return;
		}
		stk[tp++] = c;
	}

	char pop()
	{
		if (isEmpty())
		{
			error("push on a empty stack");
		}
		return stk[--tp];
	}

	char top()
	{
		if (isEmpty())
		{
			error("push on a empty stack");
		}
		return stk[tp-1];
	}
	
	bool isEmpty()
	{
		return tp == 0;
	}

	bool isFull()
	{
		return tp >= STACK_CAPACITY;
	}
	
	~Stack() {}
};

