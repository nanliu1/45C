 #include <iostream>
using namespace std;

double convert (int a)
{
	double i;
	i = a * 6076.0 / 5280.0 / 60.0;
	return i;
}

int main ()
{
	int knots;
	cin >> knots;
	double result;
	result = convert(knots);
	cout <<  result << endl;
	return 0;
}
